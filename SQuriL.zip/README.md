# SQuriL
<!-- 🐿️🐿️🐿️ -->
Name is tentative, open to change