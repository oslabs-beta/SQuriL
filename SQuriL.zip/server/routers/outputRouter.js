const express = require('express');
const queryController = require('../controllers/outputController.js');
const router = express.Router();


module.exports = router;