

function ret() {
  const string = 'Diana'
  const empty = undefined;

  return string
}

console.log(ret())

