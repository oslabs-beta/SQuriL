import React from 'react';
import { render } from 'react-dom';
import App from './components/App';

render(
    // <h1>Testing</h1>,
    <App />,
    document.getElementById('app'),
);